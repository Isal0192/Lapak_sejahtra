import Link from "next/link";
import prisma from "@/lib/prisma";
import { Button, buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

async function ensureSeed() {
  let tenant = await prisma.tenant.findFirst();
  if (!tenant) {
    const owner = await prisma.owner.create({
      data: {
        nama: "Bapak Warung",
        nomer_tlp: "08123456789",
        alamat: "Jl. Merdeka No 1",
        email: "owner@warung.com"
      }
    });

    tenant = await prisma.tenant.create({
      data: {
        id_owner: owner.id,
        nama_warung: "Warung Berkah",
        alamat_warung: "Jl. Merdeka No 1",
      }
    });
  }
  return tenant.id;
}

export default async function Home() {
  const tenantId = await ensureSeed();

  return (
    <div className="min-h-screen bg-teal-50 flex flex-col items-center justify-center p-6">
      <div className="text-center space-y-6 max-w-lg">
        <div className="w-20 h-20 bg-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-lg">
          <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
        </div>
        <h1 className="text-4xl font-extrabold tracking-tight text-teal-900">SiPMuT Lapak Sejahtera</h1>
        <p className="text-lg text-teal-700">Aplikasi Manajemen Titip Barang (Konsinyasi) Multi-Tenant untuk Warung.</p>
        
        <div className="pt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Link href={`/titip?tenant_id=${tenantId}`} className={cn(buttonVariants({ size: "lg" }), "bg-emerald-600 hover:bg-emerald-700 text-white shadow-md")}>
            Simulasi QR Code (Form Penitip)
          </Link>
          <Link href="/login" className={cn(buttonVariants({ size: "lg", variant: "outline" }), "border-teal-300 text-teal-800 hover:bg-teal-100 shadow-sm")}>
            Login ke Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
